
package pizzería_monchamixta;


public class Personalizar {
    
    public String pepperoni;
    public String Aceitunas ;
    public String pollo;
    public String tomate;
    public String piña;
    public String quesoparmesano;
    public String pimientoverde;
    public String cebolla;
    public String anchoas;
    public String carnevacuno;
    public String bacon;
    public String SalsaBBQ;
    public String SalsaTomate;
    public String PanArtesano;
    public String Pandelacasa;  
    
    
    public void Precios(){
        
        
    }
    
    
    public void Tamaño(){ 
        
        
    }
    
    public void Ingredientes(){
        
        
        
    }
    
    public void Tipopan(){
        
        
        
    }
    
    public void TipoSalsa(){
        
        
    }
    
    public void NombrePizza(){
        
        
        
    }
    
    public void Total(){
        
        
    }
    
    
}
