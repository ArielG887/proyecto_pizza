
package pizzería_monchamixta;

import java.util.Scanner;


public class Entrega {
    public int modoenvio;
    public String Express;
    public String Establecimiento;
    public String Interés;
    public String Dirección;
    String mensaje = "";
    String resp;
  Scanner sc = new Scanner(System.in);
    
    
    public void TipoEntrega(){
        do {
            System.out.println("\nPor favor indicar donde quieres su pizza:"
                    + "\n1=establecimieno"
                    + "\n2=Express");
         modoenvio = sc.nextInt();
            sc.nextLine();
      
           if(modoenvio==1){
            mensaje = "Usted desea comer su pizza en el establecimiento.";
        }
        else{
            if(modoenvio==2){
                mensaje = "Usted desea que su pizza sea enviada a su casa o establecimiento de trabajo.";
                
           System.out.print("por favor ingresar la direcion a la que desea que sea enviada su pizza ");
            Dirección = sc.nextLine();
            sc.nextLine();
               
            } 
           }
            System.out.println("Desea continuar si o no ?");
           resp = sc.nextLine();         
        }while(resp.equals("si")); 
  }
        
        
        
    }
 
             
