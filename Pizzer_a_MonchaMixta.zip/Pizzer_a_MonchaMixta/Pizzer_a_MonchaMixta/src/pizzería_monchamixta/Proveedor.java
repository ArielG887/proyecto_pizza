
package pizzería_monchamixta;


public class Proveedor {
    private int conteo;
   private String proveedor= "Envutidos americano";
   private String proteinas= "Salami";
    private String proteinas1= "peperoni";
     private String proteinas2= "Anchoas";
      private String proteinas3= "pollo";
       private String proteinas4= "Bacon";
        private String proteinas5= "Carne vacuna";
   private String proveedor1= "Quesos del norte";
    private String lacteos=" Queso";
    private String lacteos1=" Queso parmesano";
   private String proveedor2= "Buena harina";
    private String Harinas="Harina";
    private String Harinas1="Harina integral";
   private String proveedor3= "Pasta y salsas del campo";
    private String salsas="Pasta de tomate";
     private String salsas1="SalsaBBQ";
   private String proveedor4="distruvidor de verduras y frutas";
    private String verduras="Cebolla";
     private String verduras1="Pimentones";
      private String verduras2="Champiñones";
       private String verduras3="Aceitunas";
       private String verduras4="Piña";
       
    
    static void ListaProveedores()
    {
    }
    public String getProveedor(){
        return proveedor;
    }
    public void setProveedor(String proveedor){
        this.proveedor = proveedor;   
    }
    public String getProteinas(){
        return proteinas;
    }
    public void setProteinas(String proteinas){
        this.proteinas = proteinas;   
    }
    public String getProteinas1(){
        return proteinas1;
    }
    public void setProteinas1(String proteinas1){
        this.proteinas1 = proteinas1;   
    }
    public String getProteinas2(){
        return proteinas2;
    }
    public void setProteinas2(String proteinas2){
        this.proteinas2 = proteinas2;   
    }
    public String getProteinas3(){
        return proteinas3;
    }
    public void setProteinas3(String proteinas3){
        this.proteinas3 = proteinas3;   
    }
    public String getProteinas4(){
        return proteinas4;
    }
    public void setProteinas4(String proteinas4){
        this.proteinas4 = proteinas4;   
    }
    public String getProteinas5(){
        return proteinas5;
    }
    public void setProteinas5(String proteinas5){
        this.proteinas5 = proteinas5;   
    }
    public String getProveedor1(){
        return proveedor1;
    }
    public void setProveedor1(String proveedor1){
        this.proveedor1 = proveedor1;
        
    }
    public String getLacteos(){
        return lacteos;
    }
    public void setLacteos(String lacteos){
        this.lacteos = lacteos;   
    }
    public String getLacteos1(){
        return lacteos1;
    }
    public void setLacteos1(String lacteos1){
        this.lacteos1 = lacteos1;   
    }
    public String getProveedor2(){
        return proveedor2;
    }
    public void setProveedor2(String proveedor2){
        this.proveedor2 = proveedor2;
        
    }
    public String getHarinas(){
        return Harinas;
    }
    public void setHarinas(String Harinas){
        this.Harinas = Harinas;   
    }
     public String getHarinas1(){
        return Harinas1;
    }
    public void setHarinas1(String Harinas1){
        this.Harinas1 = Harinas1;   
    }
    public String getProveedor3(){
        return proveedor3;
    }
    public void setProveedor3(String proveedor3){
        this.proveedor3 = proveedor3;
        
    }
    public String getSalsa(){
        return salsas;
    }
    public void setSalsas(String salsas){
        this.salsas = salsas;   
    }
     public String getSalsa1(){
        return salsas1;
    }
    public void setSalsas1(String salsas1){
        this.salsas1 = salsas1;   
    }
    public String getProveedor4(){
        return proveedor4;
    }
    public void setProveedor4(String proveedor4){
        this.proveedor4 = proveedor4;
        
    }
    public String getVerduras(){
        return verduras;
    }
    public void setverduras(String verduras){
        this.verduras = verduras;   
    }
     public String getVerduras1(){
        return verduras1;
    }
    public void setverduras1(String verduras1){
        this.verduras1 = verduras1;   
    }
     public String getVerduras2(){
        return verduras2;
    }
    public void setverduras2(String verduras2){
        this.verduras2 = verduras2;   
    }
     public String getVerduras3(){
        return verduras3;
    }
    public void setverduras3(String verduras3){
        this.verduras3 = verduras3;   
    }
     public String getVerduras4(){
        return verduras4;
    }
    public void setverduras4(String verduras4){
        this.verduras4 = verduras4;   
    }
    public void ConteoProductos(){
        
        
    }
}
