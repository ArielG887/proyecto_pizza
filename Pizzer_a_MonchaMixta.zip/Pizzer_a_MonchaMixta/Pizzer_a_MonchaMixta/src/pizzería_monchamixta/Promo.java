
package pizzería_monchamixta;


public class Promo {
    
    private int kilo;
   
    
    
    public void CollabNissan() {
        
        
    }
    
    
}
