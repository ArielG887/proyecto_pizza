
package pizzería_monchamixta;


public class Combos {
    public String Grande;
    public String Mediano;
    public String Especial;
    public String Suprema;
    public String Hawaiana;
    public String Jamónyqueso;
    public String Solocarnes;
    public String  brasileña;
    public String tejana;
    public int dcto;
    
    
    public void Precioscombos(){
    
}
    
    
    
    public void TipoCombo(){
        
        
        
    }
    
    public void TipoTamaño(){
        
        
    }
    
    public void Facturar(){
        
    }
    
}
