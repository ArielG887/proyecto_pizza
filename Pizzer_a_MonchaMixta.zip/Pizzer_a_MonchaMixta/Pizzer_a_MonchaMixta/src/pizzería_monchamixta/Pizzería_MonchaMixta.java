
package pizzería_monchamixta;


public class Pizzería_MonchaMixta {

    
    public static void main(String[] args) {
       Cliente datos = new Cliente();
       Cliente.SolicitarDatos();
       
        System.out.println("\n El nombre es: "+datos.GetNombre());  
        System.out.println("\nla cedula es: "+datos.GetCedula());
    
    Proveedor lista = new Proveedor(); 
   Proveedor.ListaProveedores();
   
   
   Pago tipo = new Pago();
   tipo.TipoPago();
   
   
   Entrega Envio = new Entrega();
   Envio.TipoEntrega();
    }
  
}
