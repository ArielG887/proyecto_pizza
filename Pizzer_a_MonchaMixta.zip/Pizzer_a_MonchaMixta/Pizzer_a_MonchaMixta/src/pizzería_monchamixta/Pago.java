
package pizzería_monchamixta;

import java.util.Scanner;


public class Pago {
  private int Tarjeta;
  private int efectivo;
  private int bitcoin;
  int modopago;
  String resp;
  String mensaje = "";
  Scanner sc = new Scanner(System.in);
  public void TipoPago() {
  
      
        do {
            System.out.println("\nPorfavor ingresar un numero para elegir la forma de pago deseada forma de pago:"
                    + "\n1=Tarjeta"
                    + "\n2=Efectivo"
                    + "\n3=Bitcoin");
         modopago = sc.nextInt();
            sc.nextLine();
      
           if(modopago==1){
            mensaje = "Usted desea pagar con Targeta.";
        }
        else{
            if(modopago==2){
                mensaje = "Usted desea pagar en Efectivo.";
            }
            else{
                if(modopago==3){
                    mensaje = "Usted desea pagar con Bitcoin.";
                }
            }
           }
            System.out.println("Desea continuar si o no ?");
           resp = sc.nextLine();         
        }while(resp.equals("si")); 
  }
}
        
  
  
  
      
 
        
    

