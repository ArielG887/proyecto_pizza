
package pizzería_monchamixta;

import java.util.Scanner;

public class Cliente {
    private int cédula;
       private String nombre;
       private int telefono;
      private boolean correo;
        String resp;
        Scanner sc = new Scanner(System.in);
    
    static void SolicitarDatos(){
       
    
    }
        do {
    
     System.out.print("\n Vienbenido a la"
             + "Pizeria Moncha Mixta");
    
            System.out.print("Ingrese un su nombre");
            nombre = sc.nextLine();
            sc.nextLine();{
            
            
            System.out.println("Ingrese su nomero de cedula");
            cédula = sc.nextInt();
            sc.nextLine();
            
            System.out.println("Ingrese su nomero de telefono");
            telefono = sc.nextInt();
            sc.nextLine();
            
              System.out.println("Ingrese su nomero de correo");
              correo = sc.nextBoolean();
            sc.nextLine();
            
            System.out.print("\nGracias por su compra "
                    + "\nPor favor vuelva pronto");       
        
            System.out.println("Desea continuar si o no ?");
           resp = sc.nextLine();         
        }while(resp.equals("si")); }
        
        public void SetNombre(String nom){
        this.nombre =nom;
        
        }
        public String GetNombre(){
        return nombre;
        }
   public void SetCedula(int cédula){
        this.cédula = cédula;
        
        }
        public int GetCedula(){
        return cédula;
        }
        public void SetTelefono(int telefono){
        this.telefono = telefono;
        
        }
        public int GetTelefono(){
        return telefono;
        }
         public void SetCorreo(boolean correo){
        this.correo = correo;
        
        }
        public boolean GetCorreo(){
        return correo;
        }
}


  